<?php
    //MYSQL ALTERE CONFORME SEUS DADOS
    const DBDRIVER = 'mysql';
    const HOST = 'mysql-133493-0.cloudclusters.net:19486';
    const DBNAME = 'gerenciar_recursos';
    const DBUSER = 'admin';
    const DBPASS = '1br5fzoD';